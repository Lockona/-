<template>
  <div class="app-container">
    <el-button type="primary" @click="handleAddRole">添加用户</el-button>

    <el-table :data="rolesList" style="width: 100%; margin-top: 30px" border>
      <el-table-column align="center" label="姓名" width="220">
        <template slot-scope="scope">
          {{ scope.row.fields.name }}
        </template>
      </el-table-column>
      <el-table-column align="center" label="用户ID" width="220">
        <template slot-scope="scope">
          {{ scope.row.fields.uid }}
        </template>
      </el-table-column>
      <el-table-column align="header-center" label="人脸数">
        <template slot-scope="scope">
          {{ scope.row.fields.face_num }}
        </template>
      </el-table-column>
      <el-table-column align="center" label="操作">
        <template slot-scope="scope">
          <!-- <el-button
            type="primary"
            size="small"
            @click="handlecheck(scope)"
          >添加</el-button> -->
          <el-button  type="primary"
            size="small" @click="onUploadPic(scope)">上传图片</el-button>
          <el-button
            type="primary"
            size="small"
            @click="handlecheck(scope)"
          >查看</el-button>
          <el-button
            type="danger"
            size="small"
            @click="handleDelete(scope)"
          >删除</el-button>
        </template>
      </el-table-column>
    </el-table>

    <el-dialog
      :visible.sync="dialogVisible"
      :title="dialogType === 'edit' ? 'Edit Role' : 'New Role'"
    >
      <el-form :model="role" label-width="80px" label-position="left">
        <el-form-item label="姓名">
          <el-input v-model="role.name" placeholder="Name" />
        </el-form-item>
        <el-form-item label="用户ID">
          <el-input v-model="role.uid" placeholder="ID" />
        </el-form-item>
      </el-form>
      <div style="text-align: right">
        <el-button
          type="danger"
          @click="dialogVisible = false"
        >取消</el-button>
        <el-button type="primary" @click="confirmRole">确认</el-button>
      </div>
    </el-dialog>
  <el-dialog
      :visible.sync="dialogVis"
      :title="'人脸数据列表'"
    >
      <el-table :data="facesList" style="width: 100%; margin-top: 30px" border>
      <el-table-column align="center" label="face_token" >
        <template slot-scope="scope">
          {{ scope.row.face_token }}
        </template>
      </el-table-column>
      <el-table-column align="center" label="添加时间" >
        <template slot-scope="scope">
          {{ scope.row.ctime }}
        </template>
      </el-table-column>
      <el-table-column align="center" label="操作">
        <template slot-scope="scope">
          <el-button
            type="danger"
            size="small"
            @click="faceDelete(scope)"
          >删除</el-button>
        </template>
      </el-table-column>
    </el-table>
     <p></p>
      <div style="text-align: center">
        <el-button
          type="danger"
          @click="getRoles()"
        >退出</el-button>
       
      </div>
    </el-dialog>
  </div>
</template>

<script>
import path from 'path'
import { deepClone } from '@/utils'
import {
  getRoutes,
  getRoles,
  addRole,
  deleteRole,
  updateRole
} from '@/api/role'

const defaultRole = {
  uid: '',
  name: '',
  face_num: '',
  routes: []
}

export default {
  data() {
    return {
      role: Object.assign({}, defaultRole),
      routes: [],
      rolesList: [],
      facesList: [],
      dialogVisible: false,
      dialogVis: false,
      dialogType: 'new',
      checkStrictly: false,
      defaultProps: {
        children: 'children',
        label: 'title'
      }
    }
  },
  computed: {
    routesData() {
      return this.routes
    }
  },
  created() {
    // Mock: get all routes and roles list from server
    this.getRoutes()
    this.getRoles()
  },
  methods: {
    async getRoutes() {
      const res = await getRoutes()
      this.serviceRoutes = res.data
      this.routes = this.generateRoutes(res.data)
    },
    async getRoles() {
      this.dialogVis = false
      const res = await getRoles()
      console.log(res)
      this.$axios.get('/user/show')
      .then((response) => {
        console.log(response.data.all)
          this.rolesList = response.data.all
       
      })
      .catch(function (error) {
          console.log(error);
      });
      
    },

    // Reshape the routes structure so that it looks the same as the sidebar
    generateRoutes(routes, basePath = '/') {
      const res = []

      for (let route of routes) {
        // skip some route
        if (route.hidden) {
          continue
        }

        const onlyOneShowingChild = this.onlyOneShowingChild(
          route.children,
          route
        )

        if (route.children && onlyOneShowingChild && !route.alwaysShow) {
          route = onlyOneShowingChild
        }

        const data = {
          path: path.resolve(basePath, route.path),
          title: route.meta && route.meta.title
        }

        // recursive child routes
        if (route.children) {
          data.children = this.generateRoutes(route.children, data.path)
        }
        res.push(data)
      }
      return res
    },
    generateArr(routes) {
      let data = []
      routes.forEach((route) => {
        data.push(route)
        if (route.children) {
          const temp = this.generateArr(route.children)
          if (temp.length > 0) {
            data = [...data, ...temp]
          }
        }
      })
      return data
    },
    handleAddRole() {
      if (this.$refs.tree) {
        this.$refs.tree.setCheckedNodes([])
      }
      this.dialogType = 'new'
      this.dialogVisible = true
    },
    handlecheck({ $index, row }) {
      this.dialogVis = true
      this.$axios.get('/face/show/?data='+JSON.stringify({'uid':row.fields.uid}))
      .then((response) => {
        if(response.data.result.face_list)
        {
          this.facesList = response.data.result.face_list
        }  
      })
      .catch(function (error) {
          console.log(error);
      });
      
    },
     faceDelete({ $index, row }) {
      this.$confirm('确定删除么?', 'Warning', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      })
      .then(async() => {
          this.$axios.get('/face/del/?data='+JSON.stringify({'face_token':row.face_token}))
          .then((response) =>{
            if (response.data.error === "success") {
              deleteRole(row.face_token)
              this.facesList.splice($index, 1)
              this.$message({
              type: 'success',
              message: '删除成功!'
              });
            }
          })
          .catch(function (error) {
            console.log(error);
          });
        
      })
        .catch((err) => {
          console.error(err)
        })
    },
    handleDelete({ $index, row }) {
      this.$confirm('确定删除么?', 'Warning', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      })
      .then(async() => {
          this.$axios.get('/user/del/?data='+JSON.stringify({'uid':row.fields.uid}))
          .then((response) =>{
            if (response.data.error === "success") {
              this.$message({
              type: 'success',
              message: '删除成功!'
              }); 
              this.getRoles() 
            }
          })
          .catch(function (error) {
            console.log(error);
          });
        
      })
        .catch((err) => {
          console.error(err)
        })
    },
    generateTree(routes, basePath = '/', checkedKeys) {
      const res = []

      for (const route of routes) {
        const routePath = path.resolve(basePath, route.path)

        // recursive child routes
        if (route.children) {
          route.children = this.generateTree(
            route.children,
            routePath,
            checkedKeys
          )
        }

        if (
          checkedKeys.includes(routePath) ||
          (route.children && route.children.length >= 1)
        ) {
          res.push(route)
        }
      }
      return res
    },
    async confirmRole() {
      const isEdit = this.dialogType === 'edit'
      this.$axios.get('/user/add/?data='+JSON.stringify({'name':this.role.name,'uid':this.role.uid}))
     .then((response) =>{
      this.getRoles() 
    })
    .catch(function (error) {
      console.log(error);
    });
      // const checkedKeys = this.$refs.tree.getCheckedKeys()
      // this.role.routes = this.generateTree(
      //   deepClone(this.serviceRoutes),
      //   '/',
      //   checkedKeys
      // )
      // console.log('new')
      // if (isEdit) {
      //   await updateRole(this.role.uid, this.role)
      //   for (let index = 0; index < this.rolesList.length; index++) {
      //     if (this.rolesList[index].uid === this.role.uid) {
      //       this.rolesList.splice(index, 1, Object.assign({}, this.role))
      //       break
      //     }
      //   }
      // } else {
      //   console.log('new45')
      //   const { data } = await addRole(this.role)
      //   this.role.uid = data.uid
      //   this.rolesList.push(this.role)
      // }

      const { face_num, uid, name } = this.role
      this.dialogVisible = false
      this.$notify({
        title: 'Success',
        dangerouslyUseHTMLString: true,
        message: `
            <div>用户ID: ${uid}</div>
            <div>姓名: ${name}</div>
          `,
        type: 'success'
      })
     
    },
    //上传图片
    onUploadPic({ $index, row }) {                                  //这个写在script里面
      const input = document.createElement("input");
      input.type = "file";
      input.multiple = "multiple";
      input.accept = ".JPG, .PNG, .JPEG,.jpg, .png, .jpeg,.svg";
      input.addEventListener("change", (e) => {
        console.log(e);
        var files = new FormData();
        this.fileList = [];
        for (let i = 0; i < e.target.files.length; i++) {
          files.append("files", e.target.files[i]);
          this.fileList.push(e.target.files[i]);
        }
        let config = {
              headers:{'Content-Type':'multipart/form-data'}
        };
        let success = 0;
        for (let i = 0; i < this.fileList.length;i++)
        {
          console.log("fileList:", this.fileList[i].name);
          const reader = new FileReader(); 
          reader.readAsDataURL(this.fileList[i]);
          reader.onload = () => 
          {
            let params = new FormData() ; //创建一个form对象,必须是form对象否则后端接受不到数据
            console.log(row.fields.uid);
            params.append('uid',row.fields.uid);
            params.append('file',reader.result);  //append 向form表单添加数据
            this.$axios.post('/face/add/?data=',params,config)
            .then((response) =>{
              if (response.data.error === "success") {
                success = success + 1;
                console.log(success);
                this.$message({
                  type: 'success',
                  message: '成功添加'+success+'张'
                }); 
                this.getRoles();
              }
            })
            .catch(function (error) {
              console.log(error);
            });
          } 
        }  
      });
      input.click();
      
    },
    // reference: src/view/layout/components/Sidebar/SidebarItem.vue
    onlyOneShowingChild(children = [], parent) {
      let onlyOneChild = null
      const showingChildren = children.filter((item) => !item.hidden)

      // When there is only one child route, the child route is displayed by default
      if (showingChildren.length === 1) {
        onlyOneChild = showingChildren[0]
        onlyOneChild.path = path.resolve(parent.path, onlyOneChild.path)
        return onlyOneChild
      }

      // Show parent if there are no child route to display
      if (showingChildren.length === 0) {
        onlyOneChild = { ...parent, path: '', noShowingChildren: true }
        return onlyOneChild
      }

      return false
    }
  }
}
</script>

<style lang="scss" scoped>
.app-container {
  .roles-table {
    margin-top: 30px;
  }
  .permission-tree {
    margin-bottom: 30px;
  }
}
</style>
